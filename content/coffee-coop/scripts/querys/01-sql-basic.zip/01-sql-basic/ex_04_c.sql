-- Exercise: WHERE con ILIKE — Municipios con 'Pamplona' en todo el país
-- c) Municipalities whose name contains 'Pamplona' case-insensitively, ordered alphabetically

SELECT
    T1.municipality_code AS municipality_code,
    T1.municipality_name AS municipality
FROM 
    geo.municipalities AS T1
WHERE 
    T1.municipality_name ILIKE '%Pamplona%'
ORDER BY 
    T1.municipality_name ASC;

/*
 municipality_code | municipality
-------------------+--------------
 54518             | Pamplona
(1 fila)
*/